#!/usr/bin/env bash
# Facebook OG scrape for a live URL. Token is optional for read, required for scrape=true.
set -euo pipefail
URL="${1:-}"
if [ -z "$URL" ]; then
  echo "usage: scrape.sh https://stories.ahightower.com/slug/"
  exit 2
fi

TOKEN=""
for f in \
  "${FB_ACCESS_TOKEN:-}" \
  $HOME/workspace/custom-skills/fb_og_scrape/fb-token \
  $HOME/workspace/custom-skills/fb_og_scrape/fb-token \
  "$HOME/workspace/custom-skills/fb_og_scrape/fb-token"
do
  if [ -n "${FB_ACCESS_TOKEN:-}" ]; then
    TOKEN="$FB_ACCESS_TOKEN"
    break
  fi
  if [ -f "$f" ]; then
    TOKEN="$(tr -d ' \t\r\n' < "$f")"
    break
  fi
done

ENC="$(python3 -c "import urllib.parse,sys; print(urllib.parse.quote(sys.argv[1], safe=''))" "$URL")"

echo "URL $URL"

if [ -n "$TOKEN" ]; then
  echo "MODE scrape"
  RESP="$(curl -sS -X POST "https://graph.facebook.com/v21.0/?id=${ENC}&scrape=true&access_token=${TOKEN}")"
  echo "$RESP" | python3 -c "
import json,sys
raw=sys.stdin.read()
try:
    d=json.loads(raw)
except Exception:
    print(raw[:800]); sys.exit(1)
if 'error' in d:
    e=d['error']
    print('ERROR', e.get('code'), e.get('type'), e.get('message'))
    sys.exit(1)
print('TITLE', d.get('title') or d.get('og_object',{}).get('title'))
print('DESC', (d.get('description') or '')[:180])
img=d.get('image')
if isinstance(img, list) and img:
    print('IMAGE', img[0].get('url') if isinstance(img[0], dict) else img[0])
elif isinstance(img, str):
    print('IMAGE', img)
print('OK scrape accepted')
"
else
  echo "MODE read-only no token"
  RESP="$(curl -sS "https://graph.facebook.com/v21.0/?id=${ENC}&fields=og_object,title,description")"
  echo "$RESP" | python3 -c "
import json,sys
raw=sys.stdin.read()
try:
    d=json.loads(raw)
except Exception:
    print(raw[:800]); sys.exit(1)
if 'error' in d:
    e=d['error']
    print('ERROR', e.get('code'), e.get('type'), e.get('message'))
    print('NEED_TOKEN')
    sys.exit(2)
print('CACHED', json.dumps(d)[:500])
print('NEED_TOKEN to force refresh')
"
fi
