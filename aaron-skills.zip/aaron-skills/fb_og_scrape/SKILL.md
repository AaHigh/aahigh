# Facebook OG scrape

Ported from Aaron's Grok skill `fb-og-scrape` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

Aaron publishes from iPhone. He uses the Facebook app. He will not log into developers.facebook.com on mobile Safari. Do the scrape here.

## Hard limit

Facebook will not refresh a URL unless a Graph access token is present. There is no public anonymous Scrape Again. Do not pretend a browser tab of the debugger works without his session.

## Default action after every High Tower story push

1. Confirm the live URL returns 200.
2. Confirm og:image on the live HTML matches the file you expect.
3. Run bash ~/workspace/custom-skills/fb_og_scrape/scripts/scrape.sh with the live URL.
4. Report one of three states in plain English.

## States

- OK scrape accepted. Token worked. Messenger updates on the next share. Old posts keep the old card until reshared.
- NEED_TOKEN. No token file or Graph refused. Do not send him to the debugger page. Point at the one-time token drop.
- ERROR. Print the Graph message. Usually the token expired. Same drop.

## One-time token drop

Preferred file

~/workspace/custom-skills/fb_og_scrape/fb-token

Raw token only. No quotes. No Bearer. One line.

Get it once from Graph Explorer or a Page token on a page he admins. After that the file is the interface. Never store the token in memory.md, story HTML, GitHub, or a zip.

If the file is missing, say so in one sentence and stop.

## What a successful scrape does not do

It does not rewrite a post already in the group feed. That card is frozen to the first scrape. He must post the URL again or edit the post and reattach the link.

It does not change Pages HTML. If the new og image is not in the repo, scrape only refreshes the old image.

## After-scrape checklist

1. Repo has the new og image and HTML points at it.
2. Scrape returned OK or NEED_TOKEN.
3. If OK, share the URL as a new post or reattach the link.
4. Do not open developers.facebook.com on the phone.

## Coupling

High Tower story generation should call this skill after stories.ahightower.com/slug is live.
