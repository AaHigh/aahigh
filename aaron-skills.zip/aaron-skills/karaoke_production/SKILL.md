# Production karaoke recording

Use this skill whenever the user records karaoke and wants production quality. The method records the voice on one DJI mic and the played karaoke on a second mic as a sync reference, pulls the clean backing track digitally from the YouTube file when it can be downloaded, and mixes the voice over the clean track in post. When the YouTube audio cannot be downloaded (yt-dlp reports it as not available/prohibited, confirmed 2026-11-23), fall back to the second mic's mono recording of the played karaoke as the music track, and label the result as the fallback mix.

## Set up the receiver and microphones

- Confirm the hardware is the DJI Mic Mini. Its receiver has no screen and shows two small LEDs. The Mic 2 has a touchscreen instead and uses different steps, so do not apply this section to a Mic 2.

- Put the receiver in stereo before recording. Double-press the linking button on the receiver and watch the receiver status LED change from solid green to solid cyan. Green means mono, cyan means stereo. Do not hold the button down, holding it for two seconds starts linking instead.

- Clip transmitter 1 on the singer for the voice. Place transmitter 2 by the second phone's speaker so it hears the karaoke as it plays. Transmitter 1 records to the left channel and transmitter 2 records to the right channel.

- Play the karaoke video on the second phone. That phone is only a cue so the singer knows where to sing. Its sound is never part of the final mix, except in the fallback mix, where mic2's recording of it is the music track.

- Record video and audio on the first phone with the receiver plugged in. The recording holds one stereo audio track with the voice on the left and the played music on the right.

## Prepare the three tracks

- Run the ffmpeg commands in iSH in the folder that holds the recording and the downloaded karaoke video file. The clean-track command only applies when a YouTube file was actually downloaded.

- Split the stereo take into two mono files with this command, swapping in the real video filename. The first file is the voice and the second file is the played music.

```
ffmpeg -i video.mp4 -filter_complex "[0:a]channelsplit=channel_layout=stereo[left][right]" -map "[left]" mic1.wav -map "[right]" mic2.wav
```

- Pull the clean backing track out of the downloaded YouTube video file with this command, swapping in the real video filename. This is the track the final mix uses.

```
ffmpeg -i karaoke.mp4 -vn karaoke.wav
```

- If the YouTube audio cannot be downloaded, skip the clean track entirely. The mix uses mic2.wav as the mono music track under the voice, and the result is labeled the fallback mix. The YouTube link is still pasted, for the song title/description and the unique filename, so the vocal never lands on the wrong song.

- Do the split in iSH before importing anything. The free Premiere app on iPhone cannot split a stereo clip into two tracks, so do not try to separate the channels inside Premiere.

## Mix in Premiere on iPhone

- Import the video, mic1.wav, mic2.wav, and karaoke.wav (when a clean track was downloaded) into Premiere on the iPhone.

- Drag mic2.wav on the timeline until its waveform lines up with karaoke.wav. The two tracks hold the same song, so their waves match. The voice rides in sync automatically because both microphones share the receiver's clock and cannot drift apart. Skip this step in the fallback mix — the voice and the music are already in sync because they came from the same recording.

- Mute or delete mic2.wav once the tracks are aligned. It is only a timing ruler and never belongs in the final mix. In the fallback mix mic2.wav is the music track, so keep it and mix the voice over it instead.

- Mix mic1.wav over karaoke.wav (over mic2.wav in the fallback mix) and set the balance between the voice and the music track by ear.

## Rules that do not change

- Pull the clean backing track digitally from the YouTube file whenever it can be downloaded. When it cannot (yt-dlp blocked), use mic2's mono recording of the played karaoke as the music track and label the mix as the fallback — that is the only case where speaker-recorded music goes into the mix.

- Export mic1.wav (voice) and mic2.wav (room music) as two separate WAV files from the single phone recording, so the user can bring them into Premiere and mix each track independently — mute the mic until singing starts, trim noise at the beginning and end.

- Sync by waveform, not by clapping. The second microphone exists so the take can be lined up without a clap.

- Use mono only when a single microphone is recording. With one mic, keep the receiver LED green so the voice sits centered. Stereo with one mic puts the voice on the left channel only and leaves the right channel empty.

- Keep the receiver in stereo whenever both microphones are recording. Mono mixes the two microphones into one channel and the voice can never be pulled apart from the music again.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.

- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.
