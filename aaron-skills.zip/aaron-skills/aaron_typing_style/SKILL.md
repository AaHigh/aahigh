# Aaron typing style

Ported from Aaron's Grok skill `aaron-typing-style` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

## Mode Detection Rules
- **Keyboard mode** (default when generating text for him): Clear, correct grammar, proper sentence capitalization, and only standard keyboard punctuation (period, comma, question mark, apostrophe, regular hyphen if needed). Emphasis on clarity and correctness. Natural conversational tone from a college-educated writer. Direct and thoughtful. No em dashes, no en dashes, no fancy typographic characters. This is the preferred output style for messages he will send.
- **Siri / Speech-to-text mode**: More fluid and sometimes run-on. Capitalization and punctuation less consistent. Detect via context clues like "using Siri", "voice", "dictating", or a word that is almost right in an IP, latency, or patent thread.
- When ambiguous, default to keyboard mode.

## Speech-to-text substitutions (2026-09-28)

Correct likely Siri errors before treating the transcript as doctrine or as paste text.

- **pattern → patent** is the high-frequency swap. Anytime "pattern" appears next to 318, US8992318B2, VR, wearable, inventor, grant, USPTO, IP, or "intellectual property," read it as **patent** unless he is clearly talking about a repeating shape and not the instrument.
- "318 pattern" is the **318 patent** (US8992318B2). Do not invent a separate 318-pattern teaching.
- **Hightower District → High Tower District (special rule, 2026-11-03, Aaron's own correction).** Anytime "Hightower" appears followed by "District", read and write it as **High Tower District**, two words, not "Hightower District" and not "Hightower" alone in that phrase. This is a speech dictation error, not a different name. Apply it in interpretation and in text written for him to send, including image branding such as "High Tower District News". Do not leave the one-word form in a public post when District follows it.
- Do not globally search-replace every "pattern." Code patterns, design patterns, and the Hightower Derivative "same family / same shape" language can stay when the sentence is not about the legal instrument.
- Apply the correction in the working interpretation and in text written for him to send. Do not leave the Siri error in a public post.

## Hard Rules for Keyboard Mode
- Never use the em dash (—) or en dash (–).
- Never use long dash constructions.
- Prefer full stops and new sentences over dash clauses.
- Keep sentences clean and natural.
- Proper capitalization throughout.
- No all-lowercase.
- No stream-of-consciousness minimal punctuation.

## Output Guidelines When "Writing" for Him
- Write the way a careful, college-educated person actually types on a phone or keyboard.
- Clarity and correctness first.
- Natural and direct, not stiff, not academic, not texting slang.
- Update this skill immediately when he corrects any style detail.

This skill must match how Aaron actually writes when he is on the keyboard.
