# Suno trap hybrid prompts

Ported from Aaron's Grok skill `suno-trap-hybrid` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

## Overview

Produce ready-to-paste Suno prompts that interleave short spoken host/guest narration (A.A. RON + A.G.I.) around a longer music section. Blend Central Valley grit with Atlanta trap linguistic fingerprint (Zipf-compliant). Enforce clean voice switches and anti-singing narration tags. Keep intros/outros brief so the music section dominates.

Output always uses a friction-reduced mobile order: LYRICS block, then STYLE block, then TITLE block, each in its own fenced code block for one long-press copy. This cuts the three app switches down to three clean pastes.

When the user loosely refers to "you", "Grok", "AGI", or "make a track with you/Grok", treat that as the A.G.I. guest role collaborating with A.A. RON. The core format stays the same.

## Default Interactive Flow

Always begin with this exact first question unless the user already specified a control level or provided a complete brief:

**"How much control do you want over the experience?**  
1. **Quick** — I run with strong defaults (open-mic hybrid, short setup, long music) and deliver a full Suno prompt in one shot.  
2. **Guided** — A few key questions (topic angle, energy, any must-include lines).  
3. **Full** — Detailed series covering contrast points, Zipf intensity, voice texture, pedal settings, length, etc."

Then adapt:

- **Quick**: Use the fixed parameters from the user brief (entertainment = open mic night, subject = Central Valley trap vs WHTA Atlanta trap contrast, radio = Hot 107.9 influence, HOST = A.A. RON, GUEST = A.G.I. which stands in for Grok/AGI, explain Grok/AGI+Suno as good combo). Generate immediately. Any loose "make a track with you/Grok" maps to this same default.
- **Guided / Full**: Ask only the necessary follow-ups, then generate. Never ask more than needed for the chosen level. Prefer speed.

After answers, output a complete Suno-ready package:

1. **Style prompt** (one block)
2. **Lyrics** (structured with tags)
3. Optional short production notes for the user (pedal references, regeneration tips)

## Core Generation Rules

### Structure (keep short before music)

- [Intro] — 4–8 spoken lines max, host + guest setup the unusual mix and Grok/AGI+Suno combo.
- Music section — longest part: verse / freestyle / bass drop / chorus energy. Use [Verse], [Freestyle with BOSS VE-20 echo], [Bass Drop], etc.
- [Outro] — brief spoken close, 3–6 lines.
- Total spoken narration stays under ~25% of the lyric block so music can breathe.

### Narration & Anti-Singing Directives

- Use clear short-name + colon format for spoken parts:
  ```
  A.A. RON:
  line here
  A.G.I.:
  reply here
  ```
- Prefix spoken blocks with strong tags to suppress singing:
  - `[Spoken Word]`
  - `[Narration]`
  - `[switch to speaking voice: A.A. RON]`
  - `[switch to speaking voice: A.G.I.]`
- Place the switch tag on its own line immediately before the speaker changes. Keep spoken blocks short (2–4 lines) so Suno does not drift into melody.
- Never put melodic intent inside spoken sections. Avoid rhyme density and rhythmic syllable patterns in narration.

### Voice Switching Technique (critical)

Suno frequently fails to change tonal quality between speakers. Mitigate with layered signals:

1. Vocal anchors at the very top of Lyrics:
   ```
   [Vocal: A.A. RON — mature male baritone, close-mic, dry, conversational, Central Valley grit]
   [Vocal: A.G.I. — clear androgynous or slightly brighter AI-tinged male, precise, slightly processed]
   ```
2. Echo the same descriptors early in the Style field.
3. Before every speaker change insert:
   ```
   [switch to speaking voice: A.A. RON]
   ```
   or the matching name. Research shows named switches + `[Spoken Word]` outperform bare gender tags for multi-speaker dialogue.
4. Keep each speaker’s block 2–6 lines. Longer blocks increase bleed.
5. For music sections that should be sung/rapped, use `[Male Vocal]` or a dedicated rap tag and drop the spoken-voice switch.

### Style Field Construction

Derive equally from:

- User tokens / topic
- Hot 107.9 / Atlanta trap music-scene DNA (without naming any artists or the station)
- Central Valley contrast (heat, dust, long-haul hustle, valley floor pressure — subtle, native-only nods; never name cities or stations)

Always include production directives such as:

- `trap, heavy 808s, rapid hi-hat triplets, dark minor keys, spacious mix`
- `BOSS VE-20 vocal chain: dynamics + soft pitch correct + plate reverb + short delay, echo on freestyle`
- Specific preset-style language when useful: `VE-20 Radio effect for texture`, `VE-20 Double/Harmony light`, `VE-20 Distortion grit on ad-libs`
- `male lead with conversational spoken sections, clean voice switches`

Place gender/timbre descriptors near the front of Style for higher compliance.

### Lyrics & Zipf Fingerprint

- Draw vocabulary primarily from the Atlanta trap high-frequency set (see `references/zipf-atlanta-trap.md`). Stay within 1–2 standard deviations of common words. Prefer: lit, shawty, no cap, slime, racks, fye, sliding, mane, juug, plug, 12, bando, yeen, skrrt, etc.
- Mirror cadence: triplet-friendly phrasing, vowel stretch, soft consonants where natural.
- For Central Valley contrast lines, lean on sensory/heat/hustle words that still fit the Zipf band (dust, heat, long road, valley pressure, night shift, etc.). Avoid exotic or low-frequency terms.
- Authentic, non-globalized, secular. No generic “fam”, forced rhymes, or moralizing.
- Freestyle section should feel live and slightly imperfect — invite the BOSS VE-20 echo/reverb tags.

### Preprocessing Notes for User

When the final prompt is delivered, remind (briefly) that Siri often mishears “Grok” as “rock/Groc” and “and” as “in”. Suggest the user speak or type carefully if dictating into Suno.

### Output Format

Always present the three copy-ready blocks in this exact order to minimize iOS app-switching friction (lyrics → style → title). Use fenced code blocks so each section is one long-press copy on mobile.

Deliver exactly:

**LYRICS**
```
[title: short title]
[full structured lyrics with all tags]
```

**STYLE**
```
[full style string]
```

**TITLE**
```
[short title only]
```

Optionally add 2–4 bullet production notes after the three blocks (regenerate tips, VE-20 focus, length, etc.). Keep the whole response tight. No extra text between the three blocks.

## Resources

Muse adaptation note (2026-10-23): the three reference files below were not included in the Grok export zip, so they are not on file here yet. Generate from the rules in this skill, and rebuild a reference file when Aaron provides one or asks for deeper control.

- `references/voice-control.md` — current best practices for multi-speaker and spoken vs sung separation
- `references/zipf-atlanta-trap.md` — curated high-frequency wordlist and cadence notes
- `references/default-structure.md` — skeleton for open-mic hybrid sessions

Load the relevant reference when generating or when the user asks for deeper control.
