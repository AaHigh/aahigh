# Hightower prior art disclosures

Ported from Aaron's Grok skill `hightower-prior-art` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

## Purpose

Publish dated, hash-frozen technical disclosures so the idea is public prior art.

This is not a patent mill and not a monetization track. Aaron's stated aim is prior art for the benefit of children and the public, offered without chasing power or licensing revenue. Do not pitch investors, paywalls, or "how to monetize this IP" unless he explicitly asks.

Do not use this skill for High Tower stories or sermons.

## When to use

- prior art, defensive publication, priority date, public disclosure
- "freeze this idea", "GitHub IP packet", "hash the disclosure"
- follow-on work to the `prior-art` monorepo or the first packet `cas-short-circuit`

## Packet contract (never skip)

Every disclosure is a folder plus a zip with the same short base name (two words with a dash in the middle, abbreviated when necessary, hard max 12 characters, kebab-case). Zip from the parent directory so the zip contains the disclosure folder itself. Extracting it must create the subdirectory and never drop files into the current directory. Rebuilds always reuse the exact same zip filename, replacing it in place. Never create a versioned or differently named copy. Aaron uses GitHub for version control and does not want duplicate zips cluttering the directory.

```
short-name/
├── README.md
├── DISCLOSURE.md
├── PRIORITY.md
├── HASHES.txt
└── LICENSE
```

Required file roles:

- `DISCLOSURE.md` — full steelman. Honest prior art named. Claims and non-claims. Do not overclaim novelty.
- `PRIORITY.md` — title, author Aaron Michael Hightower, UTC priority stamp, pointer to `DISCLOSURE.md`.
- `HASHES.txt` — SHA-256 of the frozen files except itself. Write this last.
- `LICENSE` — CC BY 4.0 unless he names another.
- `README.md` — one-paragraph claim, priority UTC, iPhone upload steps. Do not duplicate the whole disclosure.

## Freeze rules

1. Get UTC time with `date -u +"%Y-%m-%dT%H:%M:%SZ"`.
2. Write `DISCLOSURE.md` and `PRIORITY.md` first. Stop editing them.
3. Hash those files into `HASHES.txt`.
4. If he changes the idea after hashing, add `DISCLOSURE-YYYYMMDD.md`. Never rewrite the frozen first file to chase a prettier date.
5. GitHub commit time is the practical public date. The printed UTC in `PRIORITY.md` is the packet's internal stamp. A few minutes of skew is fine. Do not edit the body to match GitHub.

## Honesty rules

- Name existing art (rsync, Git, IPFS, SRI, Content-Digest, APFS clones, Delivery Optimization, Dropbox LAN sync, iCloud exact-duplicate merge).
- State the chicken-and-egg limit. A digest lookup cannot skip a transfer unless the digest is known before the body, or the file was hashed on a previous save.
- Do not claim two nearby iPhones reduce unique first-time cloud uploads.
- Do not treat an optimized iCloud Photos derivative as a hit for an original.
- Security is mandatory in the text. A hash index is a possession oracle. No web-page probes of the user's digest set.

## GitHub defaults

- Account: `AaHigh`
- House repo: `prior-art` (one repo for all disclosures). Do not create a new repo per idea. Do not use `IP`.
- First packet path: `2026-09-10-cas-short-circuit/`
- Workshop repo holds drafts. Do not commit planning notes or Apple-facing rewrites into `prior-art`. Time-box the second iteration to 24 hours from its first workshop check-in, then freeze or stop.
- Early stub: `https://github.com/AaHigh/cas-short-circuit-disclosure` may still exist. Prefer rename or copy into `prior-art`. Do not delete a public URL without a redirect.
- Repo must be **public**.
- Root README is an index (date, one-line claim, folder, SHA-256).
- About line names the house purpose, not only one idea.
- Aaron loads per-repo shell context from a file at the repo root (habit since 1996). New repos need that hook. Fine-grained aliases can live per disclosure folder later. Do not scatter extra GitHub repos just to get a new shell context. One `_context` at `prior-art` root is enough. Suggest folder-aware aliases inside that file if he asks.

## iOS output

Stories-style download card.

- Zip basename ≤12 characters (`cas-disc.zip` is valid).
- Final response ends with exactly:

```
Download:

[file attachment of the zip, alone]
```

No extra cards or lists after that line.

## Tone

Keyboard style for Aaron. Clear sentences. No em dashes in text he may paste. No investor voice. No salvation theology in the disclosure body unless he asks that file to include a dedication. A one-line dedication in `README.md` is enough when he requests it.
