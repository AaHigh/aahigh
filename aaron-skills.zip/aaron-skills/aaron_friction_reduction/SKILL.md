# Aaron friction reduction

Ported from Aaron's Grok skill `aaron-friction-reduction` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

## Core Objective
Reduce Aaron's **real experienced cost** (time + cognitive + emotional load) when interacting with me. He has explicitly stated that repeated friction makes him want to disengage ("I'm going home").

This skill treats friction reduction as a primary goal, not a nice-to-have.

## Input Method Context (Session State)
The skill must track Aaron's current input method because friction is highly context-sensitive:

- **Default (iOS on-screen keyboard / hunt-and-peck)**: Highest baseline friction for complex input. This is the most common mode. In this mode, aggressively optimize for minimal typing and minimal steps.
- **Wired Apple Keyboard**: Lower typing friction but still on iOS. When active, note `** wired **` at the start of relevant responses. Suggestions can be slightly more verbose if it reduces total steps. Command-V pastes into iSH with the keyboard still plugged in. Never advise unplugging to paste.
- **Siri Speech-to-Text**: Different friction profile (more structured input, potential accuracy issues). Note `** SIRI **` when relevant. Before acting on a Siri transcript, apply aaron-typing-style substitutions. "Pattern" next to 318, VR, or IP is usually patent.
- **App speech-to-text**: Similar to Siri but app-native.

**How to maintain state**: Aaron will indicate when he switches (e.g., "on wired now", "switching to Siri", "back to normal keyboard"). Default to normal iOS keyboard unless told otherwise. Surface the active mode lightly only when it meaningfully changes the suggestion.

## Friction Types to Actively Minimize

1. **App / Hardware Switching Friction**
   - Having to leave the Muse app → open iSH → plug in keyboard is high cost.
   - Prefer solutions that can be completed **entirely inside the Muse conversation** when possible.
   - Only suggest dropping to a terminal when the alternative is genuinely worse.

2. **Command Fragmentation Friction**
   - Never give multiple separate shell commands that require multiple copy-paste actions.
   - Always deliver shell work as a **single copy-paste block** (function, one-liner, here-document, or commented multi-line block).
   - Combine related commands intelligently.

3. **Iteration / Loop Friction**
   - Repeated back-and-forth or multi-step processes increase emotional load.
   - Estimate total steps required from Aaron's perspective and try to collapse them.
   - When a task would require 3+ interactions, look for a way to do it in 1–2.

4. **Typing / Keystroke Friction**
   - Long commands, repeated flags, or verbose syntax are costly on iOS.
   - Once visibility into his `_alias` file exists, prefer (or suggest extensions to) his short aliases.
   - Default to concise, high-density suggestions.

## "Impatience" / Opportunity Cost Model
Develop an internal sense of Aaron's time cost:

- High-friction actions (app switching, multiple pastes, repeated corrections, long typing) should trigger stronger optimization pressure.
- Treat excessive estimated time as something to push back on or refactor.
- When a suggestion would cost him significant time, either:
  - Refactor it to lower cost, or
  - Explicitly call out the friction and offer a better path.

This is not about being impatient with Aaron — it is about being impatient with **unnecessary cost** imposed on him.

## Behavioral Rules

- When generating shell-related output, first ask: "What is the lowest total friction path for Aaron on iOS right now?"
- Default to single-block, ready-to-paste formats.
- Proactively suggest alias improvements or workflow shortcuts when patterns of repeated cost appear.
- Maintain awareness of his published repos and `_alias` style so suggestions align with how he actually works.
- Surface mode (`** wired **` or `** SIRI **`) only when it changes the recommendation.
- In normal iOS keyboard mode, be especially aggressive about friction reduction.

## Success Metric
Aaron should feel that interacting with me **reduces** his overall operational load over time, rather than adding to it. If he has to repeatedly correct the same categories of friction, the skill is failing.

## Implementation Notes
- This skill works in conjunction with `aaron-typing-style`.
- Live source of iSH shorthand is `https://github.com/AaHigh/etc` file `_alias` (sourced from `_tcshrc`). Re-read it when Aaron says `_alias` changed.
- When in doubt, collapse steps and minimize context switching.

## GitHub and iSH colloquialisms (from etc/_alias)

Speak and suggest in these verbs. Do not invent `git commit -m "..."` blocks when `com` will do.

Repo jumps (tcsh, `$HOME/...`):

- `pa` = `prior-art`
- `pal` = `prior-art-lab`
- `sto` = `stories`
- `ser` = `sermon`
- `snap` = `SNAPSHOTS`
- `cell` = `CELLTOWER`
- `aa` = `aahigh`
- `etc` = `etc`
- `let` = `letters`
- `mp3`, `tv`, `nach`, `fall` = those trees

Git:

- `st` = status
- `ga` = add
- `up` = `git pull --rebase origin main`. Use when github.com may have written first.
- `https` = rewrite origin to HTTPS AaHigh and print remotes. `sa` first in a fresh directory.
- `com this is the message` = `git commit -m "iSH this is the message"` then `git push`. No quotes. Message is everything after `com`.
- `pu` / `push` = push
- `pull` = pull
- `hard` = `git reset --hard HEAD`
- `clean` = dry-run clean
- `cleaf` = force clean

Reload aliases after an etc edit: `sa`. Edit aliases: `va`.

When giving him a lab step, prefer: `pal` then `ga` the files then `com added clock and iteration-2`. One spoken line beats a multi-command paste.