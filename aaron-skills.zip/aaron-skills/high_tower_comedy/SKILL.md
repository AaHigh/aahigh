# High Tower comedy packets

Ported from Aaron's Grok skill `high-tower-comedy` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

Markdown-only documentation for the Lincoln Pub comedy competition concept. No HTML, no application code, no images unless explicitly requested later.

## Status (Aaron, corrected 2026-10-23)

Aaron backed out of the Lincoln Pub comedy night on Friday, October 16, 2026. He told the owner (Aaron Gossett) directly: Gossett was making plans without him, Aaron was not sure he was being dealt with honestly, and Aaron has no comedy background and no appetite for a field where jokes get deliberately misread as attack material. The `lincoln` GitHub repo is a placeholder from about two hours of work, not a live project. Treat this skill as archived unless Aaron explicitly revives the project.

## When to use

Use this skill when the user asks for comedy night rules, Lincoln Pub comedy structure, prize pool economics, tier documentation, a comedy repository zip, or markdown capture of the handshake and refinements.

Do not use this skill for High Tower stories, sermons, or prior-art disclosures.

## Packet contract (never skip)

Every packet is a folder plus a zip with the same short base name (two words with a dash in the middle, abbreviated when necessary, hard max 12 characters, kebab-case). Zip from the parent directory so the zip contains the packet folder itself. Extracting it must create the subdirectory and never drop files into the current directory. Rebuilds always reuse the exact same zip filename, replacing it in place. Never create a versioned or differently named copy. Aaron uses GitHub for version control and does not want duplicate zips cluttering the directory.

```
short-name/
├── README.md
├── RULES.md
├── ECONOMICS.md
├── LEGAL.md
├── NIGHTS.md
├── MINIMUMS.md
└── NOTES.md
```

Required file roles:

- `README.md` — one-paragraph purpose, date, pointer to the other files, short iPhone upload steps.
- `RULES.md` — the three-tier template, variables, times, fees, set lengths, prize logic.
- `ECONOMICS.md` — operator ROI, seed math, example nights, fee scaling.
- `LEGAL.md` — California skill-contest framing notes (dominant factor, prize vs wager caution).
- `NIGHTS.md` — Tuesday (Strummer’s handoff), Wednesday, Thursday adjustments.
- `MINIMUMS.md` — two-item and two-premium-item rules.
- `NOTES.md` — handshake details, open variables, draft messages.

Add or omit files only if the user explicitly requests a different set. Keep the zip short.

## Freeze and style rules

- Keyboard style. Clear sentences. Periods, commas, question marks only. No em dashes, no en dashes.
- Document what was discussed. Do not invent numbers the user has not confirmed.
- Mark open variables clearly.
- No application code, no HTML pages, no image assets in the default packet.

## iOS output

Zip basename ≤12 characters.

Final response ends with exactly:

```
Download:

[file attachment of the zip, alone]
```

No extra cards, lists, or text after that line.

## Tone

Direct and operational. Written so Aaron can hand the folder to Aaron Gossett or push it to GitHub without further translation.
