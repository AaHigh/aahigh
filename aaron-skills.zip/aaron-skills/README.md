# Aaron Hightower — Skill Set

Thirteen skills. This is the working library I built for myself: how I write, how I ship, how I build stories, sermons, songs, and karaoke, and how I protect my ideas. The methods are the transferable part. The paths and tool names point at my setup; adapt those to yours and the skills still work.

## What's in here

| Skill | What it does |
| ----- | ------------ |
| `aaron_typing_style` | Match my keyboard writing style and correct my dictation swaps when producing text for me to send. |
| `aaron_friction_reduction` | Minimize my time, typing, and context switching on iOS in every reply and workflow. |
| `aaron_linkedin` | Write in my voice for LinkedIn. |
| `fb_og_scrape` | Pull Open Graph data from Facebook links. |
| `high_tower_comedy` | Comedy packets and bits for the High Tower District. |
| `high_tower_sermon` | Full-length sermons as standalone pages for sermon.ahightower.com. |
| `high_tower_story` | Single-file HTML stories for stories.ahightower.com. |
| `hightower_derivative` | Derivative works and thread maps. |
| `hightower_prior_art` | Prior-art disclosures, the public record of my inventions. |
| `suno_trap_hybrid` | Suno tracks in my Southern-drawled Hot 107.9 chopped and screwed style. |
| `suno_track_pages` | Version-controlled webpages for Suno tracks, with copy buttons, cover art, and a Listen section. |
| `typesafe_ai` | Type-safe AI patterns. |
| `karaoke_production` | Record production-quality karaoke on two phones with a DJI Mic Mini, split the stereo take, pull the clean backing track, and mix in Premiere. |

## How to use them

Each folder is one skill: a `SKILL.md` with the method, plus its assets, references, and scripts where it has them. Drop the folders into your assistant's skills directory (in Muse, that's the custom-skills folder) and the assistant picks them up by name. In another system, the `SKILL.md` files read as plain instructions.

## A note on what's not in here

I left out the guardrail skills that tell my assistant how to treat me (how to answer, when to stay quiet on calls, likeness rules). Those are about the assistant, not the craft. Everything in this package is the craft.

## The idea behind it

The strategy is simple: learn the new tools, build your own things, and protect the best ideas with a provisional patent. The skills are the "build your own things" part. The agents do the heavy lifting now. Your job is the flash of insight, and a patent is granted to a person, never to an agent.

— Aaron Hightower, November 2026
