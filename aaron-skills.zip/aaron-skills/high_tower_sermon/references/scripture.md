# Scripture citation

Translation default: New Living Translation (NLT).

## Order

Always reference first, quote second.

```
<p class="cite">John 8:32</p>
<blockquote>
And you will know the truth, and the truth will set you free.
</blockquote>
```

Ranges use a hyphen in the verse numbers only.

```
<p class="cite">Isaiah 5:20-21</p>
```

Do not place the reference after the quote. Do not use (NLT) after every line. One page-level note is enough: Scripture quotations are from the New Living Translation.

## Lookup rule

If wording is uncertain, search `verse NLT` and paste the NLT text. Do not blend KJV into an NLT block.

## Verses often used in these sermons

Confirm wording at publish time. These are the usual anchors:

- John 8:31-32
- John 3:19-21
- Ephesians 5:11-13
- Luke 16:10-12
- Isaiah 5:20
- Galatians 5:1
- 2 Corinthians 3:17
- Malachi 3:7
- Proverbs 29:25
- Luke 8:17
- Micah 6:8
- Proverbs 14:34
- Psalm 15:1-3
- Amos 5:24
- Matthew 5:14-16
- Romans 13:3-4 (use with care; do not baptize a party)
- James 1:22-25
- 1 Timothy 6:10
- Leviticus 19:11
- Deuteronomy 16:19-20
