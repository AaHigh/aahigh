# Real photograph policy

Only photographs of the real world. No generated saints, no fake chambers, no composite "Congress plus Fresno" art.

## Local civic sources

Pull real photos that already appear in High Tower civic work or that news and city channels published:

- Fresno City Hall exterior and council chambers
- District 3 / Tower District street, vacant commercial fronts, Belmont corridor, Tower Theatre public facade
- Planning Commission or City Council dais from official streams (frame grab of the public meeting, not a private person at home)
- Published story pages such as Murder From the Dais when the image is a photograph of a public proceeding or a public building

Search queries that stay honest:

- Fresno City Hall
- Fresno City Council chambers
- Tower District Fresno street
- Tower Theatre Fresno
- Fresno Planning Commission chambers

## Washington photographs

When the sermon climbs from District 3 to federal stewardship, include at least one real D.C. photograph:

- United States Capitol
- National Mall
- White House from a public sidewalk or park
- Supreme Court exterior
- Lincoln Memorial or Washington Monument

These must be identifiable real locations. Caption them as the seat of federal power, not as proof of a named crime.

## Captions

Every figure needs a caption with place and role in the argument. Example:

Fresno City Hall. Local stewardship starts at this door.

United States Capitol, Washington, D.C. Tax money does not become holy because it traveled farther.

## Reject

- AI people
- Private residences
- Photos meant to expose a private worker's home or children
- Memes with fake letterhead
- Uncredited screenshots of random social posts
