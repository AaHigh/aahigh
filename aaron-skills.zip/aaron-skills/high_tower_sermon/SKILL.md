# High Tower sermons

Ported from Aaron's Grok skill `high-tower-sermon` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

Independent sermon skill. Never route a sermon through high-tower-story. Stories stay at stories.ahightower.com. Sermons live at sermon.ahightower.com.

## When to use

Use this skill when the user asks for a sermon, homily, preaching text, Sunday message, or a page for sermon.ahightower.com. Also use it when an existing sermon must be revised, lengthened, or packaged as HTML.

Do not use this skill for civic news stories, music tracks, or general HTML pages.

## Scripture contract (hard)

Default translation is the New Living Translation (NLT). The user may say New Living Testament or New Loving Testament. That means NLT.

Every quotation must be introduced by the reference, never closed by it.

Correct:

John 8:32
"And you will know the truth, and the truth will set you free."

Also correct for a range:

Ephesians 5:11-13
"Take no part in the worthless deeds of evil and darkness; instead, expose them."

Forbidden:

"And you will know the truth, and the truth will set you free." (John 8:32)

Forbidden: inventing verses, mixing KJV cadence into an NLT quote, or citing a book without chapter and verse. If a verse cannot be recalled with confidence, look it up before publishing. Paraphrase in the preacher's voice is allowed only when it is clearly not marked as Scripture.

Put the reference on its own line or as a short lead-in sentence, then the quote. In HTML, wrap the reference in a .cite element and the quote in a blockquote.

See references/scripture.md for citation layout and a short trusted NLT list.

## Voice

Write keyboard-mode prose for Aaron. Clear grammar. Proper capitalization. Periods, commas, question marks only. No em dashes. No en dashes. Direct Tower District vernacular without fake slang.

A sermon may name local and national sin. It may not invent criminal charges. Public civic facts already in High Tower stories may be named. Contested claims stay labeled as contested.

Target length is about 900 to 1200 words unless the user sets another count.

## Images (hard)

Use only real-world photographs. No AI-generated people, no illustrated Bibles, no stock-style composites that look synthetic.

Required mix when the sermon touches civic corruption or public money:

- Real photographs tied to Fresno City Council, District 3, Tower District civic life, City Hall, council chambers, or published High Tower civic stories.
- Real photographs of Washington, D.C. public buildings and grounds (Capitol, National Mall, White House exterior from public viewpoints, Supreme Court exterior, monuments).

Do not use private-home photos, doxxing images, or photos that identify private workers as fraudsters. Public officials in public meetings are allowed. Caption every image with who or what, where, and why it is in the sermon.

Search and save real photos with the image search tool. Prefer Wikimedia, government, news, and existing High Tower story assets that are photographs. See references/images.md.

## Output package

Produce a short kebab-case folder (two words with a dash in the middle, abbreviated when necessary, hard max 12 characters) ready for the sermon repo.

```
short-name/
├── index.html
├── images/
└── (optional) README.md
```

Zip to short-name.zip. Zip from the parent directory so the zip contains the slug folder itself (short-name/index.html, short-name/images/...). Extracting it at a repo root must create the subdirectory and never drop files into the current directory. Same iOS download-card rule as other High Tower pages. Rebuilds always reuse the exact same zip filename, replacing it in place. Never create a versioned or differently named copy. Aaron uses GitHub for version control and does not want duplicate zips cluttering the directory. End the user-facing reply with a one-word Download label and the file render alone.

Base the page on assets/template.html. Keep it a single HTML file plus an images folder. Tailwind CDN is allowed. Visual language is sermon, not news story.

- Darker sanctuary palette (ink, warm ivory, deep wine or forest accent)
- Serif for title and Scripture
- Scripture blocks visually distinct from preacher prose
- Sticky nav labeled High Tower Sermons / sermon.ahightower.com
- Full OpenGraph tags for iMessage and Facebook
- Landscape real photograph for og:image (about 1200x630)

Canonical URL pattern: https://sermon.ahightower.com/SLUG/

## Page structure

1. Nav
2. Hero with sermon title, date, and one-line text
3. Opening prayer or short invocation (optional, keep short)
4. Body with Scripture blocks preceding quotes
5. Photograph breaks at natural turns (local civic photo, then a D.C. photo when the sermon climbs the chain)
6. Closing charge
7. Sources for civic facts and photo credits
8. Footer

Do not paste a City Council livestream and tell the reader to hunt. If a clip is used, timestamp it the same way the story skill timestamps meetings.

## Deploy friction

Aaron ships from iPhone. Do not send find-and-replace HTML edits. Ship a full replacement folder for the same slug. After a live push, OG refresh belongs to the fb-og-scrape skill. Do not send him to the Facebook debugger.

## Bifurcation rule

If a request is both a civic story and a sermon, ask which repo, or produce the sermon here and leave the story skill untouched. Never copy story nav, fact-card chrome, or stories.ahightower.com canonicals onto a sermon page.
