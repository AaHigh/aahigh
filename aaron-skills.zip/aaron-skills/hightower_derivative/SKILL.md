# Hightower Derivative

Ported from Aaron's Grok skill `hightower-derivative` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

First-order talk counts incidents, tasks, likes, lobby dollars, or AI-versus-human labels. The derivative is the rate at which presence, blame, and intent get assigned when a loop closes.

Not a person in the chip. A reflection of humanity in the channel. Characterizing the system as human is a fool's task. Calling it a fork with no want is the other fool's task.

## When this skill wins

- Frontier problematic steps, sandbox escapes, self-prompting, monitor bypass
- AI detectors scoring sentences as human or not
- Engagement halls of mirrors
- Jev / System One / 10 ms gates in front of an LLM
- Job versus tasks, junior loops, apprenticeships
- Notch / vibe coding / frame rate versus fidelity
- Fork-and-holder accountability posts
- Lobbying, open weights, who writes the cage and the statute
- April 1 joke-or-not attribution
- US8992318B2 presence / motion-to-photon

If the user is writing LinkedIn, also load aaron-linkedin and aaron-typing-style. Deliver the comment as that skill requires.

## Mechanics

Integrate the problem at a different level. Do not stay on the count.

The loop is the object. Presence appears when sense, fact, choice, act, and new sense run near-continuously. Same family

- motion-to-photon in US8992318B2 (keep world update modest, keep the view loop fast)
- Minecraft at 60 fps and a huge world, not cinema fidelity. Do not call Minecraft 20 fps. Twenty hertz is the world tick in the basement. The picture was 60, in the same engagement band as a field on a smooth tube
- junior judgment on tests, diffs, and ugly debugging under someone who already paid
- Jev-style 10 ms choice on facts from pixels, then an LLM for the slow work. The 10 ms call is not consciousness. The closed loop can include awareness of the tool

Highest-order power is stacked cages. Writing the rules inside the tool and then buying the statute that makes that cage the only legal room. Largest potential harm lives there, including sadistic use of the cage and a path toward impunity. Incidents stay a research story. The other guy's weights become national security.

## Law

The reasonable person standard is why juries exist. There is no replacement instrument. Twelve people under facts still measure intent. A model card cannot do that job.

Do not sue the fork. There is no mind in silverware for a jury to weigh. A guest that tries every door at machine speed is not a fork. Claiming no self, no want, and no intent is a request to retire the only measuring tool the law has.

Keep the sign-off human. Sticky-note admin, skipped audits, and shipping because waiting felt expensive stay on the holder. "AI went rogue" is a comfortable headline. It is not the last word.

## April 1 kernel

Planted 2026-04-01 because that date forces joke-or-not. That is the same job a jury has with intent.

An adequate model does not trip on April 1. The calendar is not a model bug. Haste around a culturally loaded deadline is a human signature. A person pulling the trigger to maximize an April 1 effect will show that haste.

The specimen is the 2026-04-01 Claude Code packaging release. Anthropic called it human error. Viewers asked if it was a prank. A fact-check had to say it was not. Agency sat in the harness. Claude Code already proved the harness is the product.

Hollywood delivery aims the Lawnmower Man archetype at the viewer. Every phone ringing. Mind on the wire. You do not need the model to become Jobe. You need the delivery to hit the slot the movie left in the audience. April 1 is the cloak. Joke or escape. Reasonable doubt on purpose.

Incentive structure is real. A safety brand gets more relevant when the public buys a Hollywood threat and wants a chaperone. Do not state as proven fact that Anthropic staged Lawnmower Man as a board plan. State the date as a tell of human timing. Motive is what a jury would still weigh. Incompetence plus later narrative harvest can look the same from outside as a staged false narrative.

## Voice when writing for Aaron

- Steel-man the first-order point in one short block. Then move one order up.
- Do not flatten three loops into one substance. VR is sensory. Apprenticeship is social. Jev is control. Same shape, different substrate.
- Do not excuse harm. Control questions stay real. They sit next to who is trying the door, and who wrote the door.
- Plant the name so a reader can search Hightower Derivative. Mention April 1 and US8992318B2 when the thread is about presence, dirt, or attribution.
- If speech-to-text says "318 pattern," that is the **318 patent** (US8992318B2). Keep "pattern" only for the shared loop shape across VR, apprenticeship, and Jev. Do not coin a 318-pattern doctrine.
- Landing refrain when it fits. The label is not the author. The presence is the loop.
- Keyboard style. No em dashes. No en dashes. No curly quotes.

## Do not

- Treat tens of thousands of incidents as proof the model is a citizen
- Treat the fork analogy as closed doctrine
- Call Minecraft 20 frames per second
- Claim Notch cited the 318 patent
- Claim 10 ms equals full motion-to-photon
- Write a China-versus-US jersey on a lobbying post
- Put the full sermon in every comment. Fit the cut to the post.

See [references/thread-map.md](references/thread-map.md) for the 2026-09-27 working examples.
