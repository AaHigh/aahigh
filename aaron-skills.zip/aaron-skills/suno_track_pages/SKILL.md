# Suno Track Pages

## Purpose

- Build a version-controlled webpage for each Suno track the user creates, in the same style as a High Tower story.
- The webpage comes first. The user copies the title, style, and lyrics from the page into Suno. GitHub holds the revision history and the created dates, never the agent chat.

## When to Use

- The user asks for a Suno track page, a track package, a track "like a story", or a zip for a track.
- Use this skill instead of ad-hoc track pages for every track from November 22, 2026 forward.
- Do not use this skill for sermons. Those belong to the high-tower-sermon skill.

## Page Components

- Put the track title at the top, then an optional subtitle, then the style of music, then the lyrics, in that order.
- Give each of the title, the style, and the lyrics its own copy button, and add one Copy All button that copies all three together.
- Show the created date and a revision line on the page, for example Revision 1 on November 22, 2026, rough draft.
- Add a short how-it-works note that says to copy from the page into Suno, to make changes on the page first, and to commit the folder to GitHub under the same name every time.
- Add an inspirations section that lists what the track draws on. Include the radio stations and sounds that define the track's vocabulary, such as Hot 107.9 and chopped and screwed Houston style, and any related tracks, whether the user's own or other artists' tracks.
- List only inspirations the user named or that are verified. Never invent a track title or an artist link for this section. When no related track exists yet, say so plainly.

## Images

- Create five images for every track.
- Make one OG image in wide landscape, 1200 by 630, for the social preview. If the generator returns a square image, center-crop it to 1200 by 630 with PIL before shipping it.
- Make four album images in LP fold-out style: front cover, back cover, inside left panel, and inside right panel.
- Show the four album images on the page as a fold-out gallery with a caption under each one.
- Keep the Tower Theatre geometry accurate when it appears: tall white tower, gold sunburst, curved facade, pink script Tower.
- Never render a recognizable likeness of a real person other than the user, and only render the user when he asks for artwork of himself.

## YouTube

- Every track page has a Listen section with a YouTube embed so the track can be played directly from the page where it was created.
- On the first iteration there is no video yet, so show a placeholder card in the Listen section instead of a player. Say plainly that the video is coming, and that the flow is to create the track in Suno, upload it to YouTube, and embed it in the next revision.
- On a later revision, replace the placeholder with a real YouTube iframe embed using the video ID, and keep a link to watch it on YouTube beside the player.
- If the track was built on a live broadcast, add a "Made Live" section after the Listen section with a second embed using the broadcast video ID, plus a link to watch the broadcast on YouTube.
- Never invent a video ID. Embed only a video the user provides or that is verified to exist.
- The video ID lives in the page, so the revision history carries it with everything else.

## Packaging

- Use a short slug for the folder and the zip: two words with a dash in the middle, hard max 12 characters. Shorten the natural slug when it runs long and use the short form everywhere.
- Build a folder with index.html and an images subfolder, then zip from the parent directory so the zip contains the slug folder itself.
- Rebuilds always reuse the exact same zip filename, replacing it in place. Never create a versioned or differently named copy.
- Save the zip at workspace/your_files/<slug>.zip and build the HTML preview beside it.
- Deliver both the preview and the zip every time, with the preview link above the zip and the final reply ending in the isolated Download pattern from the high-tower-story skill.

## OpenGraph Tags

- Put complete og and twitter meta tags in the head with absolute URLs to the track's own page, never relative paths and never the site homepage.
- Set og:url to https://tracks.ahightower.com/<slug>/ and og:image to the absolute URL of the OG image. (The track pages live on tracks.ahightower.com, in the AAHIGH/tracks repo, not on stories.ahightower.com.)
- Include og:image:width, og:image:height, og:image:alt, and og:image:secure_url, plus a canonical link to the track URL.
- If the user later picks a different home for track pages, change the base URL in this skill and in the page, and keep it consistent everywhere.

## After Generation

- Verify the zip contents before delivery: index.html plus all five images, no stray files.
- Read back each generated image and check that its text is spelled right before shipping it.
- Check that every copy button targets the right text block.

## Available connectors

- Use `muse.connector_search` to find other connectors and `muse.skill_search` to find related skills.
- If nothing here fits, look on the web for a maintained API or MCP server and set it up with [Custom Connectors and MCPs](/opt/muse/skills/custom-connector-setup/SKILL.md), or build a custom connector.
