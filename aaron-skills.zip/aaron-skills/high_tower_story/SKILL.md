# High Tower stories

Ported from Aaron's Grok skill `high-tower-story` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

## Purpose
Generate high-quality, shareable HTML stories for the High Tower District Stories repository on GitHub. These stories must look professional on mobile and desktop, render excellent rich previews in iMessage and social platforms, and adapt their internal structure, tone, and section types to match the subject. News, civic, and investigative pieces keep fact cards and sources. Philosophical, hyperbolic, narrative, or creative pieces shift toward immersive chapters, lyrical interludes, and contemplative pacing while still delivering the required HTML package and OpenGraph tags.

## When to Use
- User asks to "create a story", "make a story for the repository", "story in my High Tower District repo", "High Tower District story", or similar.
- Always use this skill instead of ad-hoc HTML generation for repository stories.
- Do not use this skill for sermons, homilies, or sermon.ahightower.com pages. Those belong to the high-tower-sermon skill.

## Format Adaptation Rule (Core Update)
Before writing, classify the subject and choose the appropriate internal structure:

- **Civic / News / Investigative**: Sticky nav, hero, fact-card row, clear source section, local context boxes, accountability tone.
- **Philosophical / Hyperbolic / Narrative / Speculative**: Longer immersive chapters, fewer or no fact cards, lyrical or poetic interludes, contemplative voice, exploration of multiple derivations or branches of an idea. Still include hero, OpenGraph, and a closing reflection. May embed lyrics blocks or placeholders for audio.
- **Creative / Music / Visual**: Emphasize lyrics, placeholders for MP3/Suno tracks, visual descriptions, and a more artistic layout while keeping the single-file HTML contract.

Never force the news template onto a non-news subject. The outer packaging (HTML, Tailwind, OpenGraph, short folder name, zip) stays constant; the inner narrative form changes to fit the material.

## Mandatory Requirements (Never Skip)
1. **OpenGraph & Twitter Cards** — Every story MUST include complete og: and twitter: meta tags in the <head>. Use a strong preview image. Set og:image to a high-quality image in the images/ folder. Include `og:image:width`, `og:image:height`, `og:image:alt`, and `og:image:secure_url`. **All og:/twitter: URLs must be absolute and point at this story, never relative and never the site homepage** — see the 2026-11-07 OG failure below.
2. **Single-file HTML + Images folder** — Produce `index.html` + `images/` subfolder. Make it zip-ready.
3. **Tailwind via CDN** + Professional Styling — Serif headings (Playfair Display), clean Inter body, slate/blue palette. Adjust spacing and card usage based on format type.
4. **Core Structure (always present)**:
   - Sticky nav with High Tower District branding
   - Hero with title, subtitle, date/badge
   - Main content (format-dependent)
   - Closing reflection or call-to-action
   - Footer
5. **Preview Optimization** — Title, description, and image must make the iMessage preview look intentional.
6. **Tone** — Match the subject. Independent and clear for civic pieces. Expansive, hyperbolic, and introspective for philosophical pieces. Always truthful to the material given.

## Template Location
Use and adapt the template in `assets/template.html` as the base. Copy it, fill in the specific story content (title, body sections, images, sources), update all og: tags, and ensure images are referenced correctly relative to the folder.

## Output Format
Always output a ready-to-use folder structure with a **short directory name** (two words with a dash in the middle, abbreviated when necessary, hard max 12 characters, kebab-case preferred). This is non-negotiable for iOS download-card reliability and typing friction.

**Aaron's reason (2026-11-07):** long directory names waste columns in `ls` listings on his Linux command line and push information off the screen — short slugs keep listings dense and readable. Enforce this when the slug is first chosen: if the natural slug from the title exceeds 12 characters, shorten it (abbreviate, drop words) and use the short form everywhere — folder, zip, og:url, canonical — never ship the long form and rename it later. A rename after deployment means a second push, a second Pages rebuild, and a second Facebook scrape.

**Recommended naming:** Concise slug only.  
Examples: `tt-april1`, `priddie`, `tower-safe`, `cell-v3`, `hf-escape`

**Forbidden (will break iOS cards):** Anything ≥13 characters or multi-word descriptive like `trusting-trust-april1`, `deputy-involved-shooting-juwan-priddie`.

Folder structure:
```
short-name/
├── index.html
├── images/
└── (optional) README.md
```

Zip the folder to `short-name.zip` (same short base name). Zip from the parent directory so the zip contains the slug folder itself. Extracting it at a repo root must create the subdirectory and never drop files into the current directory. Rebuilds always reuse the exact same zip filename, replacing it in place. Never create a versioned or differently named copy. Aaron uses GitHub for version control and does not want duplicate zips cluttering the directory.

**Critical iOS file-card rule (hard requirement — previous failures documented):**

The final response must end with exactly this isolated pattern and nothing after it:

```
Download:

[file attachment component alone on this line]
```

Rules that have already failed in production:
- Long filenames → card truncates to unreadable fragments ("trusting-") and the raw component XML leaks into the chat.
- Any surrounding markdown, lists, bold, or other cards near the render → iOS client fails to promote it to a proper download button.
- Dense "Thoughts / Structure / Folder" blocks before the render → same failure.

Self-check before sending: Is the zip name ≤12 chars? Is the file attachment the absolute last element on its own line after a one-word label? If not, fix it.

## Image Handling
- Use existing searched images when possible or search for new relevant ones.
- **For social previews**: Choose or create one dedicated high-quality preview image (ideally 1200×630px landscape, high contrast, clear subject). This goes into `og:image`. Avoid using vertical hero images for the preview tag.
- For every embedded image in the story, include a clear caption below it.
- Prioritize images that work well as social previews (high contrast, clear subject).

## Style Rules (Lock These In)
- Font: Inter for body, Playfair Display for main headings
- Colors: Slate-900/50 palette with blue-900 accents for headers
- Cards: White with subtle borders, hover lift
- Sections: Generous spacing, clear visual hierarchy
- Mobile-first and print-friendly

## YouTube and meeting video embeds (hard rule)

Never drop a raw multi-hour City Hall stream into a story and tell the reader to hunt.

If a requested clip lives inside a video longer than about 30 minutes:

1. Find a verified start time (official comment timestamp, member-posted excerpt, caption hit, or the user’s stated clock). Convert clock time to `?start=` seconds.
2. On the page, every embed card must show, in this order:
   - Who is speaking
   - Meeting and date
   - Start clock (`1:14:21`) and listen window (`about 3 minutes`)
   - One-sentence preface of the words they are about to hear
   - Then the iframe with `?start=SECONDS`
3. Prefer a short official excerpt when one exists (a councilmember’s own posted comments clip beats the six-hour stream).
4. If the start time cannot be verified, do **not** embed the long video at `t=0`. Link the source and mark **TIMESTAMP NEEDED**. Guessing “look near the end” is a defect.
5. Do not ask the reader to drag a slider on a six-hour file.

This rule exists because a High Tower story sent readers into a 6:46 City Council stream with no murder-label start and no Spidey-senses start [2026-08-28].

## Delivery rule (hard — 2026-11-07 failure)
Aaron asked for a zip and got a single-file HTML export instead — twice, after he had already said he wanted the repo package. **Never deliver a story as a single exported HTML file.** `artifact.export` is not a story delivery. Always package the story as a zip: a folder named for the slug containing `index.html` plus the `assets/` (or `images/`) folder with every referenced image, zipped to `<slug>.zip`, and deliver the zip using the isolated pattern in the Output Format section. Verify the zip's contents (index.html + all referenced assets, no stray files) before sending it.

## Preview + zip (Aaron, 2026-11-07)
Deliver BOTH every time: the zip for deployment AND a preview of the HTML alongside it, so Aaron can check it quickly without unzipping and running his iPhone simple server — that is a lot more steps for him. The preview is an addition, never a replacement for the zip. Put the preview link above the zip, and keep the isolated `Download:` pattern for the zip attachment as the last element of the reply.

## OG absolute-URL rule (hard — 2026-11-07 failure)
The "Two Laws, One Street" page shipped with `og:url` set to the site homepage (`https://stories.ahightower.com/`) and `og:image` / `twitter:image` as relative paths (`assets/hero.webp`). Facebook's Sharing Debugger followed `og:url` to the homepage and previewed the homepage's title and image instead of the story's. The slug rename did not cause this — the tags were wrong from the build. For every story, before delivery, check the shipped `index.html` head and confirm:
- `og:url` is the story's own URL (`https://stories.ahightower.com/<slug>/`), never the homepage.
- `og:image`, `og:image:secure_url`, and `twitter:image` are absolute URLs to the story's preview image (`https://stories.ahightower.com/<slug>/assets/<image>`).
- A `<link rel="canonical">` to the story URL is present.
- No `fb:app_id` is required — its absence is only a debugger warning, not a defect.

## After Generation
- Deliver the zip **only** with the isolated pattern in the Output Format section. No other content after the file attachment.
- Keep deployment instructions extremely short and sequential (extract, push). Optimize for iOS keyboard friction.
- After the user deploys, run the fb-og-scrape skill on the live URL. Do not send him to developers.facebook.com on the phone. If /home/workdir/.grok/fb-token is missing, say NEED_TOKEN once.
- Stories must include the full og:image dimensions + alt + secure_url set.

## Revision rule (hard — 2026-08-29 failure)
When a published story underperforms, or the user rejects a title/OG, do **not** send tag snippets, find-and-replace lists, or "paste this into index.html." He is on iPhone, no laptop, and editing HTML is the defect.

Ship a complete replacement folder for the **same slug**:
- `index.html` already rewritten (title, H1, og/twitter tags, 1200×630 og:image)
- `images/og-*.jpg` already in place
- zip named the slug (`d3-dais.zip`)
- deploy is unzip-over-folder + git add/commit/push only

Never ask him to touch a meta tag. Your time is cheap. His is not.

## Post-Deploy Verification (GitHub Pages Lag)
When the user asks whether a newly pushed story is live and the Pages URL still shows the old version:
1. Automatically check the raw repository file (e.g. `https://raw.githubusercontent.com/AaHigh/stories/main/<slug>/index.html` or the GitHub tree view) in parallel with the live Pages URL.
2. If the repository contains the expected updated content (new title, date badge, sections, images, etc.) but the live Pages site does not, report clearly:
   - The update is present in the repository.
   - GitHub Pages is lagging on the rebuild (common, usually 1–3 minutes, sometimes longer).
   - No further action required from the user beyond waiting and refreshing.
3. Do not force the user to dig into the repo themselves or keep refreshing while uncertain. Confirm the source-of-truth state in the repo so he can stop checking.
4. Only escalate if the repository itself is missing the expected files or content.

This rule exists to remove repeated friction around Pages propagation delay.

This skill is itself subject to the same recursive improvement loop that produced it: observed iOS failures (long names, non-isolated renders) and Pages-lag verification friction are written back into the skill so the failure modes cannot recur. Skills and code differ mainly in surface form; both are executable structures that improve by absorbing their own error cases.
