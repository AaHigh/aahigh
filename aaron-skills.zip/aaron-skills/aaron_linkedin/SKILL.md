# Aaron LinkedIn comments

Ported from Aaron's Grok skill `aaron-linkedin` on 2026-10-23. The original export is preserved at `~/workspace/skills-import/grok-export/`. Wording is Aaron's own unless marked as a Muse adaptation.

Aaron does not pay for LinkedIn. Do not use the generic 3,000-character post cap unless he explicitly says he is writing a full feed post and has confirmed it accepts 3,000.

## Measured limits (2026-09-26)

- Free-account comment (confirmed by his paste when LinkedIn started complaining): **1,250 characters**, including spaces, punctuation, and line breaks.
- If he pastes a cutoff draft, treat that paste length as the live cap for that field and fit inside it.
- Public docs still say comments are 1,250 and posts are 3,000. His cutoff matched the comment cap, not the post cap. Default to **1,250** when he says "LinkedIn comment" or when a draft dies around 1,200-1,300 characters.
- "See more" fold on feed posts is about 140-210 characters. Irrelevant for comments, which display in full up to the cap.

## Friction rule (2026-09-28)

He is on iOS. Selecting 1,250 characters out of a chat reply is the cost. Remove that cost.

Deliver the paste body as the first and only fenced block. One tap on that block copies the comment. Nothing else lives inside the fence.

Required shape

- Optional one-line label above the fence
- Then a single `text` code fence containing only the comment
- Then one count line, for example `1240 / 1250`

Rules for the fence

1. Use a `text` fence so iOS copy does not pick up a language tag as the first line.
2. Inside the fence, only the characters he will paste into LinkedIn. No title. No "Paste-ready." No count. No quotes wrapping the whole comment.
3. No trailing spaces on lines. One newline between paragraphs, matching what LinkedIn should receive.
4. Do not put a second copy of the comment in prose under the fence.
5. If he asked for feedback first, give the feedback above the fence, then the fence. Never mix feedback into the paste.

Count after the fence, one line

`1240 / 1250`

No extra commentary after that unless he asked a separate question.

## How to build the text

1. Count characters with Python `len()` on the exact string that will sit inside the fence. Include spaces and newlines.
2. Stay at or under the cap. Prefer about 1,100-1,240 so a `\r\n` vs `\n` difference cannot reject the paste.
3. Use keyboard style from aaron-typing-style. Straight apostrophes. No em dashes. No en dashes. No curly quotes. If the source line came through Siri, apply that skill's substitutions first. "318 pattern" in an IP thread is the 318 patent (US8992318B2), not a new catchphrase.
4. Finish the thought. Do not end mid-clause because the cap arrived. Rewrite earlier sentences until the landing sentence fits.
5. If he asks to fill the limit, use the space for the argument, not padding.
6. If the thread is Hightower Derivative work, also follow that skill. Still deliver through this paste shape.

## If the field is unknown

Ask once whether it is a comment or a feed post. Until answered, write to **1,250**.
